"""
BABAPPAlign: Deep learning–based progressive multiple sequence alignment engine.
"""

__author__ = "Krishnendu Sinha"
__license__ = "MIT"
__version__ = "1.0.2"
